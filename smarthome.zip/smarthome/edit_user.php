<?php 
	session_start();
	// cek apakah yang mengakses halaman ini sudah login
	if(!isset($_SESSION['level'])){
		header("location:index.php");
	}
	include "koneksi.php";
					$id = $_GET['id'];
						$data = mysqli_query($koneksi,"select * FROM user Where id_user='$id'");
						$d = mysqli_fetch_array($data)
?>
<html>
	<head>
		<title>Halaman Tambah User</title>
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<script src="js/bootstrap.min.js"></script>
		<script src="js/jquery.js"></script>
	</head>
	<body style="background-image: url('img/home.jpg'); background-repeat:no-repeat; background-attachment:fixed; 
	  -webkit-background-size: cover;
	  -moz-background-size: cover;
	  -o-background-size: cover;
	  background-size: cover;">
		<div class="text-center mt-5"><h3><font color="black">Home Automation</font></h3></div>
		  <div class="container col-sm-6">
		    <div class="card card-login mx-auto mt-3">
		      <div class="card-body">
		        <form action="proses_edit_user.php" method="POST">
		        <div class="card-header text-center"><b>EDIT USER</b></div>
		         <div class="form-group">
				  <input type="text" id="id" name ="id" class="form-control" value="<?php echo $id ?>" hidden>
		          </div>
		          <div class="form-group">
		            <label for="nama">Nama Username</label>
				  <input type="text" id="nama" name ="nama" class="form-control" placeholder="masukan nama username" value="<?php echo $d['username']; ?>" required>
		          </div>
		          <div class="form-group">
		            <label for="password">password</label>
				  <input type="text" id="password" name ="password" class="form-control" placeholder="masukan password" value="<?php echo $d['password']; ?>" required>
		          </div>
		          <div class="form-group">
				    <label for="level">Level User</label>
				    <select class="form-control" id="level" name="txt_level">
				      <option>-- pilih level --</option>
				      <option value="admin">Admin</option>
				      <option value="pengguna">Pengguna</option>
				    </select>
				  </div>
				  <div class="row">
				  <div class="col-sm-6">
		          <button class="btn btn-primary btn-block" type="submit" name="simpan">Simpan</button></div>
		          <div class="col-sm-6">
		          <a href="tambah_user.php" class="btn btn-primary btn-block">Kembali</a></div></div>
		      	</div>
		        </form>
		      </div>
		    </div>
 		 </div>
	</body>
	
</html>