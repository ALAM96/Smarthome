<?php
session_start();
	// cek apakah yang mengakses halaman ini sudah login
	if(!isset($_SESSION['level'])){
		header("location:index.php");
	}
	if ($_SESSION['level'] == 'admin') {
		$link = 'halaman_admin.php';
	}else if($_SESSION['level'] == 'pengguna'){
		$link = 'home.php';
	}
?>
<html>
	<head>
		<title>Halaman Setting</title>
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<script src="js/bootstrap.min.js"></script>
		<script src="js/jquery.js"></script>
	</head>
	<body style="background-image: url('img/home.jpg'); background-repeat:no-repeat; background-attachment:fixed; 
	  -webkit-background-size: cover;
	  -moz-background-size: cover;
	  -o-background-size: cover;
	  background-size: cover;">
		<div class="text-center mt-5"><h3><font color="black">Home Automation</font></h3></div>
		  <div class="container col-sm-5">
		    <div class="card card-login mx-auto mt-3">
		      <div class="card-body">
		        <form action="proses_setting.php" method="POST">
		        <div class="card-header text-center"><b>Pengaturan</b></div>
		        <?php	
				include "koneksi.php";
				$id = $_GET['id'];
					$data = mysqli_query($koneksi,"select id_kunci, nama_ruangan, waktu_on, waktu_off FROM tb_kunci INNER JOIN tb_ruangan ON tb_kunci.id_ruangan = tb_ruangan.id_ruangan Where id_kunci='$id'");
					$d = mysqli_fetch_array($data)
				?>

				  <input type="text" id="id" name ="id" class="form-control" value="<?php echo $d['id_kunci']; ?>" hidden>
		          <div class="form-group">
		          <label for="nama_ruangan">Nama Ruangan</label>
				  <input type="text" id="nama_ruangan" name = "nama_ruangan" class="form-control" value="<?php echo $d['nama_ruangan']; ?>" disabled>
		          </div>
		          <div class="form-group">
				  <label for="time">Waktu On</label>
				    <input class="form-control" type="text" value="<?php echo $d['waktu_on']; ?>" id="time" name="waktu_on">
				  </div>
		          <div class="form-group">
				  <label for="time2">Waktu Off</label>
				    <input class="form-control" type="text" value="<?php echo $d['waktu_off']; ?>" id="time2" name="waktu_off">
				  </div>
		          <button class="btn btn-primary btn-block" type="submit" name="simpan">Simpan</button>
		          <center><a href="<?php echo $link; ?>">Kembali</a></center>
		      	  </div>
		        </form>
		      </div>
		    </div>
 		 </div>
	</body>
</html>z