<?php 
	session_start();
	// cek apakah yang mengakses halaman ini sudah login
	if(!isset($_SESSION['level'])){
		header("location:index.php");
	}
 	include 'koneksi.php';

 	//query
 	$sql="SELECT id_kunci,nama_ruangan,status FROM tb_kunci INNER JOIN tb_ruangan ON tb_kunci.id_ruangan = tb_ruangan.id_ruangan";
	$result=mysqli_query($koneksi,$sql);
?>
<html>
	<head>
		<title>Halaman Utama</title>
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<script src="js/bootstrap.min.js"></script>
		<script src="js/jquery.js"></script>
		<script src="ikon/svg-with-js/js/fontawesome-all.min.js"></script>
	</head>
	<<body style="background-image: url('img/home.jpg'); background-repeat:no-repeat; background-attachment:fixed; 
	  -webkit-background-size: cover;
	  -moz-background-size: cover;
	  -o-background-size: cover;
	  background-size: cover;">
		<div class="text-center mt-5">
		  <div class="container col-sm-7">
		    <div class="card card-login mx-auto mt-3">
		      <div class="card-header text-center"><b>Home Automation</b></div>
		      <div class="card-body">
		        <form action="" method="POST">
		        	<div class="row">
		          <!-- <div class="custom-control custom-switch">
					  <input type="checkbox" class="custom-control-input" id="customSwitch1">
					  <label class="custom-control-label" for="customSwitch1">Gerbang Depan</label> -->
					<?php 
						while ($data=mysqli_fetch_assoc($result)) {
					?>
					<div class="card col-md-6" style="width: 15rem;">
					  <img src="img/smart.jpg" class="card-img-top" alt="...">
					  <div class="card-body">
					    <h5 class="card-title"><?php echo $data['nama_ruangan'];?></h5>
					    <div class="custom-control custom-switch">
							<input type="checkbox" class="custom-control-input" id="input<?php echo $data['id_kunci'];?>" name="input<?php echo $data['id_kunci'];?>" value="1" onchange="tamu(<?php echo $data['id_kunci'];?>)" <?php if($data['status']=='1') echo 'checked'; ?>>
						 	<label class="custom-control-label align-center" for="input<?php echo $data['id_kunci'];?>"></label>
						</div>
						<div class="mt-3">
						<a href="halaman_setting.php?id=<?php echo $data['id_kunci'];?>"><i class="fas fa-cog"></i>  setting</a>
						</div>
					  </div>
					</div>
					<?php
						}
					?>

					</div>
					<a href="index.php" onclick="return confirm('Keluar ?')">Logout</a>
		        </form>
		        <span id="data"></span>
		      </div>
		    </div>
 		 </div>
	</body>
	
</html>
<script type="text/javascript">
	function tamu(id){
		check = document.getElementById('input'+id).checked;
		
	if(check==true){

		status = '1';
		$.ajax({
			type : 'post',
			url : 'simpan.php',
			data : {"id":id,"status":status},
			success : function(data){
				$('#data').html(data);
			}
		})

		$.ajax({
			type : 'post',
			url : 'http://192.168.1.99/?GPLED2OFF',
			dataType: 'jsonp',
			data : {"id":id,"status":status},
			success : function(data){
				alert('on');
			}
		})

	}else{
		status = '0';

		$.ajax({
			type : 'post',
			url : 'simpan.php',
			data : {"id":id,"status":status},
			success : function(data){
				$('#data').html(data);
			}
		})

		$.ajax({
			type : 'post',
			url : 'http://192.168.1.99/?GPLED2ON',
			dataType: 'jsonp',
			data : {"id":id,"status":status},
			success : function(data){
				alert('off');
			}
		})
	}

	}
</script> 