<script src="D:/xampp/htdocs/smarthome/js/jquery.js"></script>
<?php
	date_default_timezone_set('Asia/Jakarta');
	$filepath = "D:/xampp/htdocs/smarthome/cron/counter.txt";
	include 'D:/xampp/htdocs/smarthome/koneksi.php';
	$sql="SELECT id_kunci,waktu_on,waktu_off,status FROM tb_kunci";
	$result = mysqli_query($koneksi,$sql);
		while ($data=mysqli_fetch_assoc($result)) {
			$id=$data['id_kunci'];
			if(date('H:i')==date('H:i',strtotime($data['waktu_on']))){

				mysqli_query($koneksi,"update tb_kunci set status=1 where id_kunci='$id'");
				$curl = curl_init();
				curl_setopt_array($curl, array(
					CURLOPT_RETURNTRANSFER => 1,
					CURLOPT_URL => 'http://192.168.1.99/?GPLED2OFF',
					CURLOPT_USERAGENT => 'Test Curl ON'
				));
				$resp = curl_exec($curl);
				curl_close($curl);

			}else if(date('H:i')==date('H:i',strtotime($data['waktu_off']))){
				//mysqli_query($koneksi,"update tb_kunci set status=1 where id_kunci='$id'");

				mysqli_query($koneksi,"update tb_kunci set status=0 where id_kunci='$id'");
				$curl = curl_init();
				curl_setopt_array($curl, array(
					CURLOPT_RETURNTRANSFER => 1,
					CURLOPT_URL => 'http://192.168.1.99/?GPLED2ON',
					CURLOPT_USERAGENT => 'Test Curl ON'
				));
				$resp = curl_exec($curl);
				curl_close($curl);

			}
		}
	$i = date('H:i:s');
	file_put_contents($filepath,$i);