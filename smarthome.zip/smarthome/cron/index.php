<?php
	$filepath = "D:/xampp/htdocs/smarthome/cron/counter.txt";
	$i = file_get_contents($filepath);
	$i = (int) $i;
	$i++;
	file_put_contents($filepath,$i);